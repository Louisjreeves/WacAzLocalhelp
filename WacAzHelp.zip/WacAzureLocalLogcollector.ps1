﻿### Wac Side Troubleshooting


# Generic PowerShell Switch Menu

function Show-Menu {
    Clear-Host
    Write-Host "==============================="
    Write-Host "       PowerShell Menu"
    Write-Host "==============================="
    Write-Host "1. Discrete check ECE errors While Update runs"
    Write-Host "2. Collect LCM events from SeedNode"
    Write-Host "3. Azure Local Log Collector"
    Write-Host "4. Windows admin center (Wac) Check and log collect Wac logs"
    Write-Host "5. Post wac and ISM removal Cleanup! (careful!)"
    Write-Host "Q. Quit"
    Write-Host "==============================="
}

do {
    Show-Menu
    $choice = Read-Host "Please select an option"

    switch ($choice) {
        '1' {
            # TODO: Add logic for Option One
            Write-Host "Discrete check ECE errors While Update runs"
            #Write-host "Hit enter to confirm this is running on the seed node" -ForegroundColor Green
            #Read-host "if not quit and run on the seed not for results"

  # Prompt for seed node name
$seedNode = Read-Host "Enter the seed node name"

# Create remote session
$session = New-PSSession -ComputerName $seedNode

# Define remote script block
Invoke-Command -Session $session -ScriptBlock {
    $eceStorePath = "C:\EceStore\efb61d70-47ed-8f44-5d63-bed6adc0fb0f"
    $files = @(
        "086a22e3-ef1a-7b3a-dc9d-f407953b0f84",
        "0b8ae09e-3e34-bd06-78a3-28c0d0d425ca",
        "1186751d-a996-d52b-69c2-425729e41c47",
        "135a629f-a4eb-28f5-f216-8fe781bb7832",
        "559dd25c-9d86-dc72-4bea-b9f364d103f8",
        "aaf13b81-7248-3de2-5cae-50bedc1aabca",
        "dcd7bf4e-5148-83f1-1fdb-dbfca46c6840",
        "e346768d-0aa5-a06d-bf95-e3ba9e0e8941"
    )
    $keywords = @("fail", "failed", "error", "exception", "warning", "denied", "unauthorized", "rejected", "invalid", "timeout", "critical", "panic", "fatal")
    $results = @()

    foreach ($file in $files) {
        $fullPath = Join-Path $eceStorePath $file
        if (-not (Test-Path $fullPath)) { continue }
        $lines = Get-Content $fullPath
        $lineNum = 0
        foreach ($line in $lines) {
            $lineNum++
            foreach ($keyword in $keywords) {
                if ($line -match $keyword) {
                    $results += [PSCustomObject]@{
                        FileName = $file
                        Line     = $line.Trim()
                        LineNum  = $lineNum
                        Keyword  = $keyword
                    }
                    break
                }
            }
        }
    }

    if ($results.Count -eq 0) {
        $results += [PSCustomObject]@{
            FileName = 'None'
            Line     = '[no matches found]'
            LineNum  = ''
            Keyword  = ''
        }
    }

    $results | Export-Csv "$eceStorePath\DeploymentKeywordMatches.csv" -NoTypeInformation -Encoding UTF8
}

# Copy the file from remote to local
$remotePath = "C:\EceStore\efb61d70-47ed-8f44-5d63-bed6adc0fb0f\DeploymentKeywordMatches.csv"
$localPath = "C:\Temp\DeploymentKeywordMatches.csv"

if (-not (Test-Path "C:\Temp")) {
    New-Item -Path "C:\Temp" -ItemType Directory | Out-Null
}

Copy-Item -Path $remotePath -Destination $localPath -FromSession $session

# Display the report
Import-Csv $localPath | Format-Table -AutoSize

# Clean up session
Remove-PSSession $session

Write-host " c:\temp now contains DeploymentKeywordMatches.csv. Review this log for failures " -ForegroundColor Green

		
		
        }
        '2' {
            # TODO: Add logic for Option Two
            Write-Host "Collect LCM events from SeedNode"
			
			# Enable specific rules related to remote event log access
Get-NetFirewallRule -DisplayGroup "Remote Event Log Management" | Set-NetFirewallRule -Enabled True


# Prompt for seed node name
$seedNode = Read-Host "Enter the seed node name"

# Ensure C:\Temp exists on local machine
$localDest = "C:\Temp"
if (-not (Test-Path $localDest)) {
    New-Item -Path $localDest -ItemType Directory | Out-Null
}

# Create remote session
$session = New-PSSession -ComputerName $seedNode

Set-NetFirewallRule -DisplayGroup 'Remote Event Log Management' -Enabled True

# Enable firewall rule on remote node
Invoke-Command -Session $session -ScriptBlock {
    Set-NetFirewallRule -DisplayGroup 'Remote Event Log Management' -Enabled True -PassThru |
        Select-Object DisplayName, Enabled
}

# Define log patterns to collect
$logPatterns = @(
    "Microsoft.AzureStack.LCMController.EventSource*.evtx",
    "Microsoft-AzureStack-HCI*.evtx"
)

# Loop through each pattern and collect matching files
foreach ($pattern in $logPatterns) {
    $remoteGlobPath = "\\$seedNode\C$\Windows\System32\winevt\Logs\$pattern"
    $matchedFiles = Get-ChildItem -Path $remoteGlobPath -ErrorAction SilentlyContinue

    foreach ($file in $matchedFiles) {
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $destFile = Join-Path $localDest "${baseName}_${seedNode}_$timestamp.evtx"
        Copy-Item -Path $file.FullName -Destination $destFile -ErrorAction Stop
        Write-Host "Copied: $($file.Name) --> $destFile"
    }
}

# Clean up session
Remove-PSSession $session

			
			
        }
        '3' {
            # TODO: Add logic for Option Three
            Write-Host "Azure Local Log Collector"
			
			



# ———— Launch in STA mode: powershell.exe -STA ————

# 1) Show date picker dialog and capture startDate
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text            = 'Select Start Date'
$form.Size            = New-Object System.Drawing.Size(280,150)
$form.StartPosition   = 'CenterScreen'

$dtPicker = New-Object System.Windows.Forms.DateTimePicker
$dtPicker.Format      = 'Short'
$dtPicker.Width       = 200
$dtPicker.Location    = New-Object System.Drawing.Point(30,20)
$form.Controls.Add($dtPicker)

# Auto-close on calendar dropdown close
$dtPicker.Add_CloseUp({
    $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Close()
})

# Optional Cancel button
$cancel = New-Object System.Windows.Forms.Button
$cancel.Text      = 'Cancel'
$cancel.Width     = 80
$cancel.Location  = New-Object System.Drawing.Point(100,60)
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancel)
$form.CancelButton = $cancel

if ($form.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
    Write-Warning "Date selection cancelled. Exiting script."
    return
}

# grab just the date portion
$startDate = $dtPicker.Value.Date
Write-Host "Start date set to $($startDate.ToString('yyyy-MM-dd'))" -ForegroundColor Cyan


# — define your menu once at the top —
$menu = [ordered]@{
  1  = 'Collect Main ALM logs'
  2  = 'Collect ALM agents logs'
  3  = 'Collect ARC agents logs'
  4  = 'Collect Bootstrap & Diagnostics logs'
  5  = 'Collect Deployment logs'
  6  = 'Collect OSupdate logs'
  7  = 'Collect Download Service logs'
  8  = 'Collect HCI Cloud Service logs'
  9  = 'Collect MOC Arb logs'
  10 = 'Collect ECE logs'
  11 = 'Collect Roles & Observability logs'
  12 = 'Collect Health Check logs'
  13 = 'Collect SDN Network logs'
  14 = 'Collect Middleware logs'
  15 = 'Collect LCM ECE Lite logs'
  16 = 'Collect Health & Monitoring logs' 
     # ← make sure this is here
  Q  = 'Quit'                               # ← and only Q quits
}




# 2) Main menu loop
do {
    Clear-Host
    Write-Host "=== Main Menu (Start Date: $($startDate.ToString('yyyy-MM-dd'))) ===`n"

    # display each numbered option plus Q
    foreach ($key in $menu.Keys) {
        Write-Host (" {0}) {1}" -f $key, $menu[$key])
    }
    Write-Host

    $choice = Read-Host "Enter choice"

    switch ($choice.ToUpper()) {
        
        '1' {Write-Host "`n[Option 1] Collecting Main ALM logs from $($startDate.ToString('yyyy-MM-dd')) to today..."
            
            # prepare destination
            $dest = "C:\Temp\ALM"
            if (-not (Test-Path $dest)) {
                New-Item -Path $dest -ItemType Directory | Out-Null
            }

            # define sources
            $sources = @(
                "C:\Observability\ALM",
                "C:\Observability\ALMSystemAgents",
                @{ Path = "C:\MASLogs"; Filter = "AgentLifeCycleManager_*" }
            )

            foreach ($src in $sources) {
                if ($src -is [string]) {
                    if (Test-Path $src) {
                        Get-ChildItem -Path $src -Recurse -File -Include *.zip,*.log,*.etl |
                          Where-Object { $_.LastWriteTime -ge $startDate } |
                          Copy-Item -Destination $dest -Force
                    }
                }
                else {
                    if (Test-Path $src.Path) {
                        Get-ChildItem -Path $src.Path -Recurse -File -Filter $src.Filter |
                          Where-Object { $_.LastWriteTime -ge $startDate } |
                          Copy-Item -Destination $dest -Force
                    }
                }
            }

            Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $dest.`n"
            }


        '2' {Write-Host "`n[Option 2] Collecting ALM agents logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for ALM agents
        $destAgents = "C:\Temp\ALM agents"
        if (-not (Test-Path $destAgents)) {
            New-Item -Path $destAgents -ItemType Directory | Out-Null
        }

        # list of agent subfolders
        $agentSources = @(
            "C:\Observability\ALMSystemAgents\FileCopyAgent",
            "C:\Observability\ALMSystemAgents\FirewallAgent",
            "C:\Observability\ALMSystemAgents\Hypersync"
        )

        foreach ($src in $agentSources) {
            if (Test-Path $src) {
                Get-ChildItem -Path $src -Recurse -File -Include *.etl,*.zip |
                  Where-Object { $_.LastWriteTime -ge $startDate } |
                  Copy-Item -Destination $destAgents -Force
            }
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destAgents.`n"
    }

        '3' {Write-Host "`n[Option 3] Collecting ARC agents logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for ARC agents
        $destArc = "C:\Temp\arc agents"
        if (-not (Test-Path $destArc)) {
            New-Item -Path $destArc -ItemType Directory | Out-Null
        }

        # all your ARC-agent log sources (wildcards & explicit files)
        $arcSources = @(
            "C:\ProgramData\AzureConnectedMachineAgent\Log\*",
            "C:\ProgramData\AzureConnectedMachineAgent\*Log",
            "C:\Windows\System32\Bootstrap\Logs\arcinstallLog.txt",
            "C:\Windows\System32\Bootstrap\Logs\setup.log",
            "C:\Windows\System32\Bootstrap\Logs\*.etl",
            "C:\Windows\System32\Bootstrap\Logs\AzStackHci.ArcConnection.Debug.log\*.txt",
            "C:\ProgramData\GuestConfig\ext_mgr_logs\*",
            "C:\ProgramData\GuestConfig\arc_policy_logs\*",
            "C:\ProgramData\GuestConfig\extension_logs\*",
            "C:\ProgramData\GuestConfig\extension_reports\*"
        )

        foreach ($src in $arcSources) {
            # grab whatever matches (files/folders) and filter by date
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destArc -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destArc.`n"
    }

         '4' {Write-Host "`n[Option 4] Collecting Bootstrap & Diagnostics logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for bootstrap & diagnostics
        $destBoot = "C:\Temp\bootstrap and diagnostics"
        if (-not (Test-Path $destBoot)) {
            New-Item -Path $destBoot -ItemType Directory | Out-Null
        }

        # all Bootstrap & Diagnostics sources (including new files)
        $bootstrapSources = @(
            "C:\ProgramData\AzureConnectedMachineAgent\Log\*",
            "C:\ProgramData\AzureConnectedMachineAgent\*.Log",
            "C:\ProgramData\GuestConfig\ext_mgr_logs\*",
            "C:\ProgramData\GuestConfig\arc_policy_logs\*",
            "C:\ProgramData\GuestConfig\extension_logs\*",
            "C:\ProgramData\GuestConfig\extension_reports\*",
            "C:\Windows\System32\Bootstrap\Logs\*",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\Bootstrap\*",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\DiagnosticsResult-*.json",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\PrerequisitesResult-*.json",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\*",
            "C:\Windows\System32\Bootstrap\Telemetry\*",
            "C:\CloudDeployment\Logs\*",
            "C:\Windows\Setup\startupscript.log"
        )

        foreach ($src in $bootstrapSources) {
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destBoot -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destBoot.`n"
    }

        '5' {Write-Host "`n[Option 5] Collecting Deployment logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for Deployment logs
        $destDeploy = "C:\Temp\deployment"
        if (-not (Test-Path $destDeploy)) {
            New-Item -Path $destDeploy -ItemType Directory | Out-Null
        }

        # source for Deployment logs
        $deploySource = "C:\CloudDeployment\Logs\*"

        Get-ChildItem -Path $deploySource -Recurse -File -ErrorAction SilentlyContinue |
          Where-Object { $_.LastWriteTime -ge $startDate } |
          Copy-Item -Destination $destDeploy -Force

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destDeploy.`n"
    }

        '6' {Write-Host "`n[Option 6] Collecting OSupdate logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for OSupdate logs
        $destOS = "C:\Temp\OSupdate"
        if (-not (Test-Path $destOS)) {
            New-Item -Path $destOS -ItemType Directory | Out-Null
        }

        # source for OSupdate logs (*.log and *.etl)
        $osSource = "C:\Windows\Logs\WindowsUpdate\*"

        Get-ChildItem -Path $osSource -Recurse -File -Include *.log,*.etl -ErrorAction SilentlyContinue |
          Where-Object { $_.LastWriteTime -ge $startDate } |
          Copy-Item -Destination $destOS -Force

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destOS.`n"
    }

        '7' {Write-Host "`n[Option 7] Collecting Download Service logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for Download Service logs
        $destDL = "C:\Temp\download service"
        if (-not (Test-Path $destDL)) {
            New-Item -Path $destDL -ItemType Directory | Out-Null
        }

        # source paths for Download Service
        $downloadSources = @(
            "C:\Windows\Logs\MoSetup\agentupdate.log",
            "C:\Windows\Logs\MoSetup\deviceinventory.xml",
            "C:\Windows\ServiceProfiles\Azure Stack HCI Download Service\*",
            "C:\Windows\SoftwareDistribution\Download\2d12f505042801c5c517655e4f65c8be\Metadata\DeviceInventory.xml"
        )

        foreach ($src in $downloadSources) {
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destDL -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destDL.`n"
    }

        '8' {Write-Host "`n[Option 8] Collecting HCI Cloud Service logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for HCI Cloud Service logs
        $destHci = "C:\Temp\HCI Cloud Service"
        if (-not (Test-Path $destHci)) {
            New-Item -Path $destHci -ItemType Directory | Out-Null
        }

        # source paths for HCI Cloud Service logs
        $hciSources = @(
            "C:\ProgramData\AzureConnectedMachineAgent\Log\azcmagent*.*",
            "C:\ProgramData\AzureConnectedMachineAgent\Log\Arc-proxy*.*",
            "C:\ProgramData\AzureConnectedMachineAgent\Log\himds*.log"
        )

        foreach ($src in $hciSources) {
            Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destHci -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destHci.`n"
    }

        '9' {Write-Host "`n[Option 9] Collecting MOC Arb logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for MOC Arb logs
        $destMocarb = "C:\Temp\mocarb"
        if (-not (Test-Path $destMocarb)) {
            New-Item -Path $destMocarb -ItemType Directory | Out-Null
        }

        # source paths for MOC Arb logs
        $mocarbSources = @(
            "C:\ProgramData\mochostagent\log\*",
            "C:\ProgramData\wssdagent\log\Agent*",
            "C:\ProgramData\wssdagent\log\wssdagent.log",
            "C:\Observability\MOC_ARB\*.log",
            "C:\Observability\MOC_ARB\*.etl",
            "C:\Observability\MOC_ARB\*.zip"
        )

        foreach ($src in $mocarbSources) {
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destMocarb -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destMocarb.`n"
    }

        '10' {Write-Host "`n[Option 10] Collecting ECE logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for ECE logs
        $destEce = "C:\Temp\ECE logs"
        if (-not (Test-Path $destEce)) {
            New-Item -Path $destEce -ItemType Directory | Out-Null
        }

        # source paths for ECE logs
        $eceSources = @(
            "C:\Observability\ECE\*.zip",
            "C:\Observability\ECE\*.etl",
            "C:\Observability\ECEAgent\CommonInfra\*.etl",
            "C:\Observability\ECEAgent\CommonInfra\*.zip"
        )

        foreach ($src in $eceSources) {
            Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destEce -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destEce.`n"
    }

        '11' {Write-Host "`n[Option 11] Collecting Roles & Observability logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for Roles & Observability logs
        $destRO = "C:\Temp\roles and observability"
        if (-not (Test-Path $destRO)) {
            New-Item -Path $destRO -ItemType Directory | Out-Null
        }

        # source paths for Roles & Observability
        $roSources = @(
            "C:\CloudContent\MASLogs\*.*",
            "C:\Observability\RemoteSupportAgent\*.etl"
        )

        foreach ($src in $roSources) {
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destRO -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destRO.`n"
    }

        '12' {Write-Host "`n[Option 12] Collecting Health Check logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for Health Check logs
        $destHC = "C:\Temp\health check"
        if (-not (Test-Path $destHC)) {
            New-Item -Path $destHC -ItemType Directory | Out-Null
        }

        # source paths for Health Check
        $hcSources = @(
            "C:\ClusterStorage\Infrastructure_1\Shares\SU1_Infrastructure_1\Updates\HealthCheck\System\*",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthService\*.etl",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthService\*.zip"
        )

        foreach ($src in $hcSources) {
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destHC -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destHC.`n"
    }

        '13' {Write-Host "`n[Option 13] Collecting SDN Network logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for SDN Network logs
        $destSdn = "C:\Temp\sdn network"
        if (-not (Test-Path $destSdn)) {
            New-Item -Path $destSdn -ItemType Directory | Out-Null
        }

        # source paths for SDN Diagnostics
        $sdnSources = @(
            "C:\Observability\NC\SDNDiagnostics\*.etl",
            "C:\Observability\NC\SDNDiagnostics\*.zip"
        )

        foreach ($src in $sdnSources) {
            Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destSdn -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destSdn.`n"
    }

        '14' {Write-Host "`n[Option 14] Collecting Middleware logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for Middleware logs
        $destMid = "C:\Temp\middleware"
        if (-not (Test-Path $destMid)) {
            New-Item -Path $destMid -ItemType Directory | Out-Null
        }

        # source paths for Middleware logs
        $midSources = @(
            "C:\Observability\CommonInfra\Middleware\*.etl",
            "C:\Observability\CommonInfra\Middleware\*.zip"
        )

        foreach ($src in $midSources) {
            Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destMid -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destMid.`n"
    }

        '15' {Write-Host "`n[Option 15] Collecting LCM ECE Lite logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for LCM ECE Lite logs
        $destLite = "C:\Temp\lcm ece lite"
        if (-not (Test-Path $destLite)) {
            New-Item -Path $destLite -ItemType Directory | Out-Null
        }

        # source paths for LCM ECE Lite
        $liteSources = @(
            "C:\MASLogs\LCMECELiteLogs\*.log",
            "C:\MASLogs\LCMECELiteLogs\*.xml"
        )

        foreach ($src in $liteSources) {
            Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destLite -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destLite.`n"
    }

        '16' {Write-Host "`n[Option 16] Collecting Health & Monitoring logs from $($startDate.ToString('yyyy-MM-dd')) to today..."

        # destination for Health & Monitoring logs
        $destHM = "C:\Temp\health and monitoring"
        if (-not (Test-Path $destHM)) {
            New-Item -Path $destHM -ItemType Directory | Out-Null
        }

        # source paths for Health & Monitoring
        $hmSources = @(
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\CommonInfra\*.etl",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\CommonInfra\*.zip",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\*.etl"
        )

        foreach ($src in $hmSources) {
            Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $startDate } |
              Copy-Item -Destination $destHM -Force
        }

        Write-Host "`nDone! Files from $($startDate.ToString('yyyy-MM-dd')) through today are in $destHM.`n"
    }

         'Q'  {Write-Host "Exiting menu..."
            break
        }


        Default {
            Write-Warning "Invalid selection. Please enter 1–26 or Q to quit."
        }
    }

    if ($choice.ToUpper() -ne 'Q') {
        Write-Host
        Read-Host "Press Enter to return to the menu"
    }

} until ($choice.ToUpper() -eq 'Q')

			
			
        }
        '4' {
            # TODO: Add logic for Option Four
            Write-Host "Basic WAC checks (windows admin center) and Open Manager Integration for WAC"
			Write-host "Executing basic setup checks for WAC- Fix on Fail "
			# Run PowerShell as Administrator

# Define the registry path
$regPath = "HKLM:\SOFTWARE\Policies\Microsoft\Edge"

# Create the registry key if it doesn't exist
if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force
}

# Set the value to disable the pop-up blocker (0 = Allow pop-ups)
New-ItemProperty -Path $regPath -Name "PopupsBlocked" -Value 0 -PropertyType DWord -Force

Write-Output "Pop-up blocker disabled in Microsoft Edge."


# Allow insecure content for a specific site
$regPath = "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
New-Item -Path $regPath -Force | Out-Null
New-ItemProperty -Path $regPath -Name "InsecureContentAllowedForUrls" -Value '["https://localhost"]' -PropertyType MultiString -Force

# Allow intrusive ads (not recommended)
New-ItemProperty -Path $regPath -Name "AdsSetting" -Value 1 -PropertyType DWord -Force


# — determine the logged‐on user (domain\user or machine\user) —
$user = (Get-CimInstance -ClassName Win32_ComputerSystem).UserName

if (-not $user) {
    # fallback if WMI returns nothing (e.g. running in a weird context)
    if ($env:USERDOMAIN -and $env:USERNAME) {
        $user = "$($env:USERDOMAIN)\$($env:USERNAME)"
    }
    else {
        Throw "Cannot determine a user to add to the group."
    }
}

Write-Host "Adding '$user' to Windows Admin Center CredSSP Administrators…" -ForegroundColor Cyan

# — add to the local group —
Add-LocalGroupMember `
    -Group "Windows Admin Center CredSSP Administrators" `
    -Member $user `
    -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    

Write-Host "Success!" -ForegroundColor Green



Write-host " Collecting logs..."
# 1) Ensure C:\Temp exists
if (-not (Test-Path -Path 'C:\Temp')) {
    New-Item -Path 'C:\Temp' -ItemType Directory | Out-Null
}

# 2) Create the collection folder
$collectDir = 'C:\Temp\WAClogcollect'
if (-not (Test-Path -Path $collectDir)) {
    New-Item -Path $collectDir -ItemType Directory | Out-Null
}

# 3) Copy the logs
Copy-Item -Path 'C:\ProgramData\Microsoft\Windows Admin Center\Logs\Dell\*'-Destination $collectDir -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

Copy-Item -Path 'C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\logs\*' -Destination $collectDir -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

# 4) Compress into a ZIP inside WAClogcollect
$zipPath = Join-Path $collectDir 'WAClogcollect.zip'
Compress-Archive -Path "$collectDir\*" -DestinationPath $zipPath -Force


Write-host "Done!!!"		
			
			
        }
        '5' {
            # TODO: Add logic for Option Five
            Write-Host "Only choose this option if you are trying to mop up a failure! you will need to redeploy OMIMSWAC and ISM modules"

            
#Cleanup step one Manual check and stop services and clear registry enties and processes 

    # Stop & disable services
 # Services to chec 'dsm_ism_srvm','dsm_ism_srvm2','dsm_ism_srvm3'
   
 # Process to check dsm_ism','ismrfutil','^omc 

    #  Optional registry wipe
    # check these registry areas if ($doForce) {
      
            #'HKLM:\SOFTWARE\Dell\SysMgt',
            #'HKLM:\SOFTWARE\Dell\iSM',
            #'HKLM:\SOFTWARE\WOW6432Node\Dell\iSM'
    Write-Host "=== [$env:COMPUTERNAME] – starting Dell iSM cleanup ===" -Foreground Cyan
    Write-host "===THIS IS DESTRUCTIVE! MAKE SURE TO HIT CONTROL C IF YOU HAVE NOT REMOVED ISM"
    Read-host "only hit enter if you have already removed the ISM and removed the cluster from wac"

$paths = @(
     
    "$env:ProgramFiles\Dell\SysMgt\iSM\*",
    'C:\ProgramData\Dell\iSM\*',
    'C:\ProgramData\Dell\iDRACTools\*',
    'C:\ProgramData\Microsoft\Windows Admin Center\ExtensionCache\Dell*',
    'C:\ProgramData\Microsoft\Windows Admin Center\Logs\Dell*',
    'C:\Users\*\AppData\Roaming\*\WacExe\*',
    'c:\Windows\Temp\OMIMSWAC\*'
    "$env:USERPROFILE\AppData\Local\Temp\*",
    "$env:USERPROFILE\AppData\Local\Temp\1\*",
    "$env:USERPROFILE\AppData\Local\Temp\2\*",
    "$env:USERPROFILE\AppData\Local\Temp\3\*"
)

foreach ($p in $paths) {
    Get-Item -Path $p -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "Removed: $($_.FullName)"
        } catch {
            Write-Warning "Failed to remove: $($_.FullName) - $_"
        }
    }
}


# Clean AppData\Roaming for all users EXCEPT the Microsoft folder
$roamingRoots = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
foreach ($user in $roamingRoots) {
    $roamingPath = Join-Path $user.FullName "AppData\Roaming"
    if (Test-Path $roamingPath) {
        Get-ChildItem $roamingPath -Force -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -ne 'Microsoft'
        } | ForEach-Object {
            try {
                Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host "Cleaned from Roaming: $($_.FullName)"
                
            } catch {
                Write-Warning "Failed to clean from Roaming: $($_.FullName) - $_"
            }
        }}
}


# === Cluster Node Cleanup Section ===

$clustername = read-host "Please enter the name of the cluster"



    $clusterNodes = (Get-ClusterNode -Cluster $clusterName).name  

# Get cluster nodes
try {
    $clusterNodes = Get-ClusterNode | Select-Object -ExpandProperty Name
    Write-Host "`n=== Found cluster nodes: $($clusterNodes -join ', ') ===" -ForegroundColor Cyan
} catch {
    Write-Warning "Failed to retrieve cluster nodes. Are you running this on a cluster-aware system?"
    return
}

# Define the cleanup script block to run remotely
$cleanupScript = {
    param($paths)

    Write-Host "=== [$env:COMPUTERNAME] – remote Dell iSM cleanup ===" -ForegroundColor Yellow

    foreach ($p in $paths) {
        Get-Item -Path $p -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host "Removed: $($_.FullName)"
            } catch {
                Write-Warning "Failed to remove: $($_.FullName) - $_"
            }
        }
    }

    # Clean AppData\Roaming for all users EXCEPT the Microsoft folder
    $roamingRoots = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
    foreach ($user in $roamingRoots) {
        $roamingPath = Join-Path $user.FullName "AppData\Roaming"
        if (Test-Path $roamingPath) {
            Get-ChildItem $roamingPath -Force -ErrorAction SilentlyContinue | Where-Object {
                $_.Name -ne 'Microsoft'
            } | ForEach-Object {
                try {
                    Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                    Write-Host "Cleaned from Roaming: $($_.FullName)"
                } catch {
                    Write-Warning "Failed to clean from Roaming: $($_.FullName) - $_"
                }
            }
        }
    }
}

# Run the cleanup script on each cluster node
foreach ($node in $clusterNodes) {
    Write-Host "`n--- Running cleanup on $node ---" -ForegroundColor Green
    Invoke-Command -ComputerName $node -ScriptBlock $cleanupScript -ArgumentList $paths
}





        }
        'Q' {
            Write-Host "Exiting the menu. Goodbye!"
        }
        default {
            Write-Host "Invalid selection. Please try again."
        }
    }

    if ($choice -ne 'Q') {
        Pause
    }

} while ($choice -ne 'Q')
